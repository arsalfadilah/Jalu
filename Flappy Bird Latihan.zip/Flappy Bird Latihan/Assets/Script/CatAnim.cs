using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatAnim : MonoBehaviour
{
    //Deklarasi
    private Animator animator;
    private Vector3 Pos;
    private float moveSpeed;
    public bool isGrounded = false;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        moveSpeed = 0.01f;
        Pos.x = 0;
        Pos.y = 0;
        Pos.z = 0;
    }

    // Update is called once per frame
    void Update()
    {
        updateTransition();
        controlMove();
    }

    private void updateTransition()
    {
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.LeftArrow))
        {
            animator.SetBool("isWalking", true);
            animator.SetBool("isJump", false);

            if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.rotation = Quaternion.Euler(0, 180, 0);
            } 
            
            if(Input.GetKey(KeyCode.RightArrow))
            {
                transform.rotation = Quaternion.Euler(0, 0, 0);
            }

        }
        else
        {
            animator.SetBool("isWalking", false);
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                animator.SetBool("isJump", true);
            }
        }
    }

    private void controlMove()
    {
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Pos.x = -moveSpeed;
            transform.position += Pos;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            Pos.x = moveSpeed;
            transform.position += Pos;
        }
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {          
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, 5f), ForceMode2D.Impulse);
        }
    }

}
