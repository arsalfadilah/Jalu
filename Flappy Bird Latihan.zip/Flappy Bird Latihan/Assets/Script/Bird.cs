using UnityEngine;

public class Bird : MonoBehaviour
{
    private PolygonCollider2D BirdPolygon;
    private Rigidbody2D MyRigid;
    private Vector3 Pos;
    private float speed;

    void Start()
    {
        BirdPolygon = GetComponent<PolygonCollider2D>();
        MyRigid = GetComponent<Rigidbody2D>();
        speed = 0.05f;
    }

    private void OnMouseDrag() 
    {
        Vector3 newPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        transform.position = new Vector3(newPos.x, newPos.y, 0);
    }
    private void Update() 
    {
        
        if(Input.GetKeyDown(KeyCode.R))
        {
            GetComponent<Renderer>().material.color = Color.red;
        }    
        if(Input.GetKeyDown(KeyCode.G))
        {
            GetComponent<Renderer>().material.color = Color.green;
        }    
        if(Input.GetKeyDown(KeyCode.B))
        {
            GetComponent<Renderer>().material.color = Color.blue;
        }
        if (Input.GetKeyDown(KeyCode.M))
        {
            BirdPolygon.enabled = false;
        }

        controlMove();
    }

    private void controlMove()
    {
        if (Input.GetKey(KeyCode.D))
        {
            Pos.x = speed;
            Pos.y = 0f;
            Pos.z = 0f;
            transform.position += Pos;
        }
        if (Input.GetKey(KeyCode.A))
        {
            Pos.x = -speed;
            Pos.y = 0f;
            Pos.z = 0f;
            transform.position += Pos;
        }

        if (Input.GetKey(KeyCode.W))
        {
            Pos.x = 0;
            Pos.y = speed;
            Pos.z = 0;
            transform.position += Pos;
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            MyRigid.bodyType = RigidbodyType2D.Kinematic;
        }
        if (Input.GetKeyUp(KeyCode.W))
        {
            MyRigid.bodyType = RigidbodyType2D.Dynamic;
        }
    }

}
