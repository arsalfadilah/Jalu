using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grounded : MonoBehaviour
{
    GameObject Jalu;
    // Start is called before the first frame update
    void Start()
    {
        Jalu = gameObject.transform.parent.gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "Groun Only")
        {
            Jalu.GetComponent<CatAnim>().isGrounded = true;
            Debug.Log("tset");
        }
        else
        {
            Debug.Log("bas");

        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if(collision.collider.tag == "Groun Only")
        {
            Jalu.GetComponent<CatAnim>().isGrounded = false;
        }
    }

}
